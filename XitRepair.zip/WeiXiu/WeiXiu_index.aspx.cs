﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;


public partial class WeiXiu_index : System.Web.UI.Page
{
    SqlHelper data = new SqlHelper();
    Alert js = new Alert();
    protected void Page_Load(object sender, EventArgs e)
    {
        

        if (!IsPostBack)
        {
            try
            {
                if (Session["adminid"] == null)
                {
                    Alert.AlertAndRedirect("对不起您还没有登录", "WeiXiu_login.aspx");
                }
                else
                {
               
                    Label1.Text = "维修师傅";
                    this.Label2.Text = Session["Admin"].ToString();
                    Get_DB();

                    SqlHelper data = new SqlHelper();
                    string id = Session["adminid"].ToString();
                    SqlDataReader dr = data.GetDataReader("select * from dbo.RePerson where id=" + id);
                    dr.Read();

                    XingMing.Text = dr["Names"].ToString();
                    Age.Text = dr["Age"].ToString();


                    

                    tel.Text = dr["Tel"].ToString();
                    sex.Text = dr["Sex"].ToString();
                    type.Text = dr["UserType"].ToString();
                    
                }
            }
            catch (Exception)
            {
                Alert.AlertAndRedirect("请重新登录!", "WeiXiu_login.aspx");
            }
          
        }

    }
    protected void gv_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {


    }
    private void Get_DB()
    {
        try
        {

//
     //   gv.DataSource = GetCodeBy(0);
           // GridView2.DataSource = GetYiwancheng(0);
          //  GridView1.DataSource = GetJinxingzhong(0);
           // GridView3.DataSource = GetSearch(0);
            //    gv.DataBind();
         //   GridView1.DataBind();
           // GridView2.DataBind();
         //   GridView3.DataBind();
            Repeater3.DataSource = GetSearch(0);
            Repeater3.DataBind();
            Repeater2.DataSource = GetJinxingzhong(0);
            Repeater2.DataBind();
            Repeater1.DataSource = GetCodeBy(300);
            Repeater1.DataBind();
            Repeater4.DataSource = GetYiwancheng(0);
            Repeater4.DataBind();
    
        }
        catch
        {

        }

    }
    protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
   //    gv.PageIndex = e.NewPageIndex;
        Get_DB();
    }
    protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //鼠标移动变色
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //当鼠标放上去的时候 先保存当前行的背景颜色 并给附一颜色 
            e.Row.Attributes.Add("onmouseover", "currentcolor=this.style.backgroundColor;this.style.backgroundColor='#f6f6f6',this.style.fontWeight='';");
            //当鼠标离开的时候 将背景颜色还原的以前的颜色 
            e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=currentcolor,this.style.fontWeight='';");
        }
        //单击行改变行背景颜色 
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Attributes.Add("onclick", "this.style.backgroundColor='#f6f6f6'; this.style.color='buttontext';this.style.cursor='default';");
        }

    }
    public DataTable  GetCodeBy(int iCount)
    {
        SqlHelper date = new SqlHelper();
        string strTop = "";
        if (iCount > 1)
        {
            strTop = "top " + iCount.ToString();
        }

        //   string sql = "select  " + strTop + "  * from [WeiXiu] where CheSate='未完成'  and   Name like '%" + search + "%'  ";
        string sql = "select  " + strTop + "  * from [Repair] where CheSate='未维修' order by  AddTime desc";
        SqlConnection con = new SqlConnection(SqlHelper.sqlconing);
        SqlCommand cmd = new SqlCommand(sql, con);

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable ds = new DataTable();
        try
        {
            con.Open();
          //  ds = new DataSet();
            da.Fill(ds);

        }
        catch (SqlException ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            con.Close();
        }
    
        return ds;
    }
    public DataTable GetJinxingzhong(int iCount)
    {
        SqlHelper date = new SqlHelper();
        string strTop = "";
        if (iCount > 1)
        {
            strTop = "top " + iCount.ToString();
        }

        string id = Session["Admin"].ToString();
        string sql = "select  " + strTop + "  * from [Repair] where CheSate='维修中' and  WXPerson='"+id +"' order by  AddTime desc";
        SqlConnection con = new SqlConnection(SqlHelper.sqlconing);
        SqlCommand cmd = new SqlCommand(sql, con);

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable ds = new DataTable();
        try
        {
            con.Open();
         //   ds = new DataSet();
            da.Fill(ds);

        }
        catch (SqlException ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            con.Close();
        }
        return ds;
    }
    public DataTable GetYiwancheng(int iCount)
    {
        SqlHelper date = new SqlHelper();
        string strTop = "";
        if (iCount > 1)
        {
            strTop = "top " + iCount.ToString();
        }
        string id = Session["Admin"].ToString();
        //string sql = "select  " + strTop + "  * from [WeiXiu] where CheSate='未完成'  and   Name like '%" + TextBox1.Text + "%'  ";
        string sql = "select  " + strTop + "  * from [Repair] where CheSate='已维修' and  WXPerson='" + id + "' order by  AddTime desc ";
        SqlConnection con = new SqlConnection(SqlHelper.sqlconing);
        SqlCommand cmd = new SqlCommand(sql, con);

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable ds = new DataTable();
        try
        {
            con.Open();
          //  ds = new DataSet();
            da.Fill(ds);

        }
        catch (SqlException ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            con.Close();
        }
        return ds;
    }
    public DataTable GetSearch(int iCount)
    {
        SqlHelper date = new SqlHelper();
        string strTop = "";
        if (iCount > 1)
        {
            strTop = "top " + iCount.ToString();
        }
        string search = this.Search.Value;
        string sql = "select  " + strTop + "  * from [Repair] where   Name like '%" + search + "%' order by  AddTime desc ";
       
        SqlConnection con = new SqlConnection(SqlHelper.sqlconing);
        SqlCommand cmd = new SqlCommand(sql, con);

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable ds = new DataTable();
        try
        {
            con.Open();
        //    ds = new DataSet();
            da.Fill(ds);

        }
        catch (SqlException ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            con.Close();
        }
        return ds;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Get_DB();
        
    }
    protected void gv3_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
       // GridView3.PageIndex = e.NewPageIndex;

        Get_DB();
    }
    protected void gv2_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
  //      GridView2.PageIndex = e.NewPageIndex;

        Get_DB();
    }
    protected void gv1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        //GridView1.PageIndex = e.NewPageIndex;

        Get_DB();
    }
}