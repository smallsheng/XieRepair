﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_ShowWXInfo : System.Web.UI.Page
{
    SqlHelper data = new SqlHelper();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["adminid"] == null)
            {
                Alert.AlertAndRedirect("对不起您还没有登录", "WeiXiu_login.aspx");
            }
            else
            {
                int id = int.Parse(Request.QueryString["id"].ToString());
                SqlDataReader dr;
                dr = data.GetDataReader("select * from  Repair where id=" + id);
                dr.Read();
                txtbig.Text = dr["WXInfo"].ToString();


                TextBox2.Text = dr["WXPerson"].ToString();

                TextBox3.Text = dr["CheSate"].ToString();


                Label1.Text = dr["name"].ToString();
                Label2.Text = dr["UserName"].ToString();
                Label3.Text = dr["Tel"].ToString();
                Label4.Text = dr["Dormitory"].ToString();
                Label5.Text = dr["ReType"].ToString();
                Label6.Text = dr["content"].ToString();
                evtext.Text = dr["evaluate"].ToString();
                Image1.ImageUrl = "../files/" + dr["RePhoto"].ToString();
                if (dr["WeiXiuPhoto"].ToString() == "")
                {
                    fk.Text = "还未反馈！";
                    Image2.Visible = false;
                }
                else
                {
                    Image2.Visible = true;;
                    Image2.ImageUrl = "../files/" + dr["WeiXiuPhoto"].ToString();
                }
               
                
         
            

            } 
        }

    }

  
}
