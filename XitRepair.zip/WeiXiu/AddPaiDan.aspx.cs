﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_AddPaiDan : System.Web.UI.Page
{
    SqlHelper data = new SqlHelper();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["adminid"] == null)
            {
                Alert.AlertAndRedirect("对不起您还没有登录", "WeiXiu_login.aspx");
            }
            else
            {
                int id = int.Parse(Request.QueryString["id"].ToString());
                data.RunSql("update   repair set  CheSate='维修中',WXPerson='" + Session["Admin"].ToString() + "',WXPersonID='" + Session["adminid"].ToString() + "'  where id=" + id);

                Alert.AlertAndRedirect("接单成功请尽快维修！！", "WeiXiu_index.aspx");
            }
 
        }

    }

   
}
