﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WeiXiu_index : System.Web.UI.Page
{
    SqlHelper data = new SqlHelper();

    Alert js = new Alert();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {


        }

    }


    protected void Button1_ServerClick(object sender, EventArgs e)
    {
      
            if (this.txtUserID.Value == "" || this.txtPwd.Value == "")
            {
                Page.RegisterStartupScript(" ", "<script>alert(' 请输入账号密码！ '); </script> ");
            }
            else
            {
                if (Session["CheckCode"].ToString() != this.userImg.Value)
                {
                    Page.RegisterStartupScript(" ", "<script>alert(' 验证码错误请重新输入 '); </script> ");
                    //Alert.AlertAndRedirect("验证码错误请重新输入", "WeiXiu_login.aspx");
                }
                else
                {
                    string userName = this.txtUserID.Value;

                    string Pwd = GetMD5(txtPwd.Value);
                    string sql = "select * from dbo.RePerson where LoginName='" + userName + "' and LoginPwd='" + Pwd + "' ";
                    SqlDataReader dr = data.GetDataReader(sql);
                    if (dr.Read())
                    {
                        Session["Admin"] = dr["Names"].ToString();
                        Session["adminid"] = dr["id"].ToString();
                        Response.Redirect("WeiXiu_index.aspx");
                        //   Response.Redirect("index.html");
                        //  Response.Write("<script language='javascript'>alert('登录成功');location.href='WeiXiu_index.aspx'</script>");
                    }
                    else
                    {
                        Page.RegisterStartupScript(" ", "<script>alert(' 登录失败，用户名或者密码错误 '); </script> ");
                        //Alert.AlertAndRedirect("登录失败", "student_login.aspx");
                    }
                }
            }
        
      

      
    }
    public static string GetMD5(String input)
    {
        string cl = input;
        string pwd = "";
        MD5 md5 = MD5.Create();//实例化一个md5对像
                               // 加密后是一个字节类型的数组，这里要注意编码UTF8/Unicode等的选择　
        byte[] s = md5.ComputeHash(Encoding.UTF8.GetBytes(cl));
        // 通过使用循环，将字节类型的数组转换为字符串，此字符串是常规字符格式化所得
        for (int i = 0; i < s.Length; i++)
        {
            // 将得到的字符串使用十六进制类型格式。格式后的字符是小写的字母，如果使用大写（X）则格式后的字符是大写字符 

            pwd = pwd + s[i].ToString("X");

        }
        return pwd;
    }
}