﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_AddWeiXiu : System.Web.UI.Page
{
    SqlHelper data = new SqlHelper();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["adminid"] == null)
            {
                Alert.AlertAndRedirect("对不起您还没有登录", "WeiXiu_login.aspx");
            }
            else
            {
                int id = int.Parse(Request.QueryString["id"].ToString());
                SqlDataReader dr;
                dr = data.GetDataReader("select * from  Repair where id=" + id);
                dr.Read();


                DropDownList1.Items.FindByText(dr["CheSate"].ToString()).Selected = true;//选项Text  

                txtbig.Text = dr["WXInfo"].ToString();
            }
        }

    }

    protected void Button1_Click(object sender, EventArgs e)
    {

        int id = int.Parse(Request.QueryString["id"].ToString());
        data.RunSql("update   Repair set  WXInfo='" + txtbig.Text + "',CheSate='" + DropDownList1.SelectedValue + "',WXTime='" + DateTime.Now.ToString() + "' ,WeiXiuPhoto='"+pic.Text+"'  where id=" + id);

        Alert.AlertAndRedirect("操作成功！！", "WeiXiu_index.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string res;
        upload up = new upload();
        res = up.Up(file1, "../files/");
        this.Label1.Visible = true;
        this.Label1.Text = up.Resup[Convert.ToInt32(res)];
        this.pic.Text = up.s;
        Image1.ImageUrl = "../files/" + pic.Text;

    }
}
