﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

public partial class Admin_ModifyPwd : System.Web.UI.Page
{
    Alert alert = new Alert();
    SqlHelper data = new SqlHelper();
    protected void Page_Load(object sender, EventArgs e)
    {
        this.Title = "修改登陆密码  ";
        if (!IsPostBack)
        {
            if (Session["adminid"] == null)
            {
                Alert.AlertAndRedirect("对不起您还没有登录", "../Login.aspx");
            }
        }
    }/// <summary>
    /// 修改密码
    /// </summary>
    private void UPpwd()
    {
        SqlHelper mydata = new SqlHelper();
        string Username = Session["adminid"].ToString();
        try
        {
            string pwds = GetMD5(txtpwd2.Text);
            string sql = "update [Admin]  set [Pwd] ='" + pwds + "' where [id]='" + Username + "' ";
            mydata.RunSql(sql);
            LabelWarningMessage.Text = "修改成功！";
        }
        catch
        {

            LabelWarningMessage.Text = "修改失败！";
        }
    }
    /// <summary>
    /// 检验原来的密码
    /// </summary>
    private void chkpwd()
    {
        SqlDataReader dr;
        string pwds = GetMD5(txtpwd1.Text);
        dr = data.GetDataReader("select * from  Admin  where id='" + Session["adminid"].ToString() + "' and Pwd='" + pwds + "'");
        if (dr.Read())
        {
            UPpwd();
        }
        else
        {
            LabelWarningMessage.Text = "原密码不正确！";
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        chkpwd();
       }
    public static string GetMD5(String input)
    {
        string cl = input;
        string pwd = "";
        MD5 md5 = MD5.Create();//实例化一个md5对像
                               // 加密后是一个字节类型的数组，这里要注意编码UTF8/Unicode等的选择　
        byte[] s = md5.ComputeHash(Encoding.UTF8.GetBytes(cl));
        // 通过使用循环，将字节类型的数组转换为字符串，此字符串是常规字符格式化所得
        for (int i = 0; i < s.Length; i++)
        {
            // 将得到的字符串使用十六进制类型格式。格式后的字符是小写的字母，如果使用大写（X）则格式后的字符是大写字符 
            pwd = pwd + s[i].ToString("X");

        }
        return pwd;
    }
}
