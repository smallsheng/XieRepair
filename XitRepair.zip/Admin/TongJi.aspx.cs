﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel; 
public partial class Admin_TongJi : System.Web.UI.Page
{

    SqlHelper data = new SqlHelper();
    Alert js = new Alert();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["adminid"] == null)
            {
                Alert.AlertAndRedirect("对不起您还没有登录", "../Login.aspx");
            }
            else
            {
                             DropDownList4.Text = DateTime.Now.Month.ToString() + "月";
                            DropDownList3.DataSource = data.GetDataReader("select * from   RePerson ");
                            DropDownList3.DataTextField = "Names";
                            DropDownList3.DataValueField = "id";
                            DropDownList3.DataBind();

                            Get_DB();
                Get_Count();

            }

           
        }

    }
    protected void gv_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {


    }
    private void Get_DB()
    {
        try
        {

               
            gv.DataSource = GetCodeBy(0);
            gv.DataBind();
        }
        catch
        {

        }

    }
    protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gv.PageIndex = e.NewPageIndex;
        Get_DB();
    }
    protected void gv_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //鼠标移动变色
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //当鼠标放上去的时候 先保存当前行的背景颜色 并给附一颜色 
            e.Row.Attributes.Add("onmouseover", "currentcolor=this.style.backgroundColor;this.style.backgroundColor='#f6f6f6',this.style.fontWeight='';");
            //当鼠标离开的时候 将背景颜色还原的以前的颜色 
            e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=currentcolor,this.style.fontWeight='';");
        }
        //单击行改变行背景颜色 
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Attributes.Add("onclick", "this.style.backgroundColor='#f6f6f6'; this.style.color='buttontext';this.style.cursor='default';");
        }

    }  string month = "";
    public DataSet GetCodeBy(int iCount)
    {
        SqlHelper date = new SqlHelper();
        string strTop = "";
      
        switch (DropDownList4.Text)
        {
            case "1月":
                month = "2019/1/1";break;
            case "2月":
                month = "2019/2/1";break;
            case "3月":
                month = "2019/3/1"; break;
            case "4月":
                month = "2019/4/1"; break;
            case "5月":
                month = "2019/5/1"; break;
            case "6月":
                month = "2019/6/1"; break;
            case "7月":
                month = "2019/7/1"; break;
            case "8月":
                month = "2019/8/1"; break;
            case "9月":
                month = "2019/9/1"; break;
            case "10月":
                month = "2019/10/1"; break;
            case "11月":
                month = "2019/11/1"; break;
            case "12月":
                month = "2019/12/1"; break;
                
        }

        if (iCount > 1)
        {
            strTop = "top " + iCount.ToString();
        } string sql = "";

        if (DropDownList1.SelectedValue == "全部")
        {
            sql = "select  " + strTop + "  * from [Repair]   where    WXPerson='" + DropDownList3.SelectedItem.Text + "'and DATEDIFF(month,[addtime],'"+month+"') = 0 ";
           
        }
        else
        {
            sql = "select  " + strTop + "  * from [Repair] where CheSate='" + DropDownList1.SelectedValue + "'   and  WXPerson='" + DropDownList3.SelectedItem.Text+ "'and DATEDIFF(month,[addtime],'" + month + "') = 0 ";
 
        }
        Get_Count();
        SqlConnection con = new SqlConnection(SqlHelper.sqlconing);
        SqlCommand cmd = new SqlCommand(sql, con);

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = null;
        try
        {
            con.Open();
            ds = new DataSet();
            da.Fill(ds);

        }
        catch (SqlException ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            con.Close();
        }
        return ds;
    }



    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Get_DB();
        Get_Count();
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        Get_DB();
        Get_Count();
    }
    public void Get_Count()
    {
        switch (DropDownList4.Text)
        {
            case "1月":
                month = "2019/1/1"; break;
            case "2月":
                month = "2019/2/1"; break;
            case "3月":
                month = "2019/3/1"; break;
            case "4月":
                month = "2019/4/1"; break;
            case "5月":
                month = "2019/5/1"; break;
            case "6月":
                month = "2019/6/1"; break;
            case "7月":
                month = "2019/7/1"; break;
            case "8月":
                month = "2019/8/1"; break;
            case "9月":
                month = "2019/9/1"; break;
            case "10月":
                month = "2019/10/1"; break;
            case "11月":
                month = "2019/11/1"; break;
            case "12月":
                month = "2019/12/1"; break;
                
        }
        SqlConnection con = new SqlConnection(SqlHelper.sqlconing);
        con.Open();
        SqlCommand cmd1 = new SqlCommand("SELECT COUNT(*)  FROM[XitRepair].[dbo].[Repair] where DATEDIFF(month, [addtime],'" + month + "') = 0 and CheSate = '已维修' and  WXPerson='" + DropDownList3.SelectedItem.Text+"' ", con);
        SqlCommand cmd2 = new SqlCommand("SELECT COUNT(*)  FROM[XitRepair].[dbo].[Repair] where DATEDIFF(month, [addtime],'" + month + "') = 0 and CheSate = '维修中' and  WXPerson='" + DropDownList3.SelectedItem.Text + "'", con);

        counts1.Text = cmd1.ExecuteScalar().ToString();
        counts2.Text = cmd2.ExecuteScalar().ToString();
        con.Close();
    }
}
