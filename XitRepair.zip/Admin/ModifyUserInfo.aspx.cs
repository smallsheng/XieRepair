﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_ModifyUserInfo : System.Web.UI.Page
{
    SqlHelper data = new SqlHelper();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            if (Session["adminid"] == null)
            {
                Alert.AlertAndRedirect("对不起您还没有登录", "../Login.aspx");
            }
            SqlHelper data = new SqlHelper();
            string id = Request.QueryString["id"].ToString();
            SqlDataReader dr = data.GetDataReader("select * from dbo.RePerson where id=" + id);
            dr.Read();

            XingMing.Text = dr["Names"].ToString();
            Age.Text = dr["Age"].ToString();
        
      

       
            Tel.Text = dr["Tel"].ToString();
            DropDownList1.Items.FindByText(dr["Sex"].ToString()).Selected = true;//选项Text  

            DropDownList2.Items.FindByText(dr["UserType"].ToString()).Selected = true;//选项Text  

      
          
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
      
            string id = Request.QueryString["id"].ToString();
            data.RunSql("update  dbo.RePerson set  Names='" + XingMing.Text + "',Age='" + Age.Text + "',Tel='" + Tel.Text + "',UserType='" + DropDownList2.SelectedValue + "',Sex='"+DropDownList1.SelectedValue+"' where id=" + id);
            Alert.AlertAndRedirect("修改成功", "UserManger.aspx");
     
    }
  
}
