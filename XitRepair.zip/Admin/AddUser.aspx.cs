﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

public partial class Admin_AddUser : System.Web.UI.Page
{
    SqlHelper data = new SqlHelper();
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (!IsPostBack)
        {
            if (Session["adminid"] == null)
            {
                Alert.AlertAndRedirect("对不起您还没有登录", "../Login.aspx");
            }

        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        String pwds = GetMD5(TextBox3.Text);

        data.RunSql("insert into dbo.RePerson(Sex,Age,Names,Tel,UserType,LoginName,LoginPwd)values('" + DropDownList1.SelectedItem.Text + "','" + Age.Text + "','" + XingMing.Text + "','" + Tel.Text + "','" + DropDownList2.SelectedValue + "','" + TextBox2.Text + "','" + pwds + "')");


          
            Alert.AlertAndRedirect("添加成功！", "UserManger.aspx");
     
    }
    public static string GetMD5(String input)
    {
        string cl = input;
        string pwd = "";
        MD5 md5 = MD5.Create();//实例化一个md5对像
                               // 加密后是一个字节类型的数组，这里要注意编码UTF8/Unicode等的选择　
        byte[] s = md5.ComputeHash(Encoding.UTF8.GetBytes(cl));
        // 通过使用循环，将字节类型的数组转换为字符串，此字符串是常规字符格式化所得
        for (int i = 0; i < s.Length; i++)
        {
            // 将得到的字符串使用十六进制类型格式。格式后的字符是小写的字母，如果使用大写（X）则格式后的字符是大写字符 
            pwd = pwd + s[i].ToString("X");

        }
        return pwd;
    }

}
