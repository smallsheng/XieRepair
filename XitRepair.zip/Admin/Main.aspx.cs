﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_Main : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    { if (Session["adminid"] == null)
        {
            Alert.AlertAndRedirect("对不起您还没有登录", "../Login.aspx");
        }
        try
        {
    Label1.Text = "管理员";
        this.Label2.Text = Session["Admin"].ToString();
       
        }
        catch (Exception)
        {

            Alert.AlertAndRedirect("请重新登录！", "../Login.aspx");
        }
    
    }
}
