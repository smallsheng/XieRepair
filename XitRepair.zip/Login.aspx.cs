﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

public partial class Login : System.Web.UI.Page
{

    SqlHelper data = new SqlHelper();

    Alert js = new Alert();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {


        }

    }


    protected void Button1_ServerClick(object sender, EventArgs e)
    {
        if (Session["CheckCode"].ToString() != userImg.Value)
        {
            Alert.AlertAndRedirect("验证码错误请重新输入", "Login.aspx");
        }
        else
        {
            if (DropDownList1.SelectedValue == "管理员")
            {
                string userName = this.txtUserID.Value;
                string pwds = GetMD5(txtPwd.Value);
                string sql = "select * from Admin where Name='" + userName + "' and Pwd='" + pwds + "' ";
                SqlDataReader dr = data.GetDataReader(sql);
                if (dr.Read())
                {
                    Session["Admin"] = dr["Name"].ToString();
                    Session["adminid"] = dr["id"].ToString();

                    Response.Write("<script language='javascript'>alert('登录成功');location.href='Admin/index.html'</script>");


                }
                else
                {
                    Alert.AlertAndRedirect("登录失败", "Login.aspx");

                }
            }
        }


    }
    public static string GetMD5(String input)
    {
        string cl = input;
        string pwd = "";
        MD5 md5 = MD5.Create();//实例化一个md5对像
                               // 加密后是一个字节类型的数组，这里要注意编码UTF8/Unicode等的选择　
        byte[] s = md5.ComputeHash(Encoding.UTF8.GetBytes(cl));
        // 通过使用循环，将字节类型的数组转换为字符串，此字符串是常规字符格式化所得
        for (int i = 0; i < s.Length; i++)
        {
            // 将得到的字符串使用十六进制类型格式。格式后的字符是小写的字母，如果使用大写（X）则格式后的字符是大写字符 

            pwd = pwd + s[i].ToString("X");

        }
        return pwd;
    }
}



