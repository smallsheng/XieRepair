﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class UserManger_ShowWXInfo : System.Web.UI.Page
{
    SqlHelper data = new SqlHelper();
    protected void Page_Load(object sender, EventArgs e)
    {
       
        if (!IsPostBack)
        {
            if (Session["adminid"] == null)
            {
                Alert.AlertAndRedirect("对不起您还没有登录", "student_login.aspx");
            }
            else
            {
                int id = int.Parse(Request.QueryString["id"].ToString());
                SqlDataReader dr;
                dr = data.GetDataReader("select * from  Repair where id=" + id);
                dr.Read();
                Label1.Text = dr["name"].ToString();
                Label2.Text = dr["UserName"].ToString();
                Label3.Text = dr["Tel"].ToString();
                Label4.Text = dr["Dormitory"].ToString();
                Label5.Text = dr["ReType"].ToString();
                Label6.Text = dr["content"].ToString();
                TextBox3.Text = dr["CheSate"].ToString();
                txtbig.Text = dr["WXInfo"].ToString();
                TextBox2.Text = dr["WXPerson"].ToString();
                Image1.ImageUrl = "../files/" + dr["RePhoto"].ToString();
                Image2.ImageUrl = "../files/" + dr["WeiXiuPhoto"].ToString();
                Label7.Text = dr["evaluate"].ToString();
                Label8.Text = dr["roomNum"].ToString();
                if (TextBox3.Text == "未维修" || TextBox3.Text=="维修中")
                {
                    this.evaluateDiv.Style.Value = "display:none";
                    this.Image2Div.Style.Value = "display:none";
                    this.evaluateBtn.Style.Value = "display:none";
                }
                if(TextBox3.Text != "未维修")
                {
                    this.reminderDiv.Style.Value = "display:none";
                }
                   if(TextBox3.Text == "已维修")
                  {
                    if(Label7.Text == "还未评价" )
                    {
                        Label7.Text = " ";
                         evaluateBtn.Style.Value = "display:block";
                    }
                    else
                    {
                        evaluateBtn.Style.Value = "display:none";
                    }
                  
                }
            }
        }

    }


    protected void evaluateBtn_Click(object sender, EventArgs e)
    {
        int id = int.Parse(Request.QueryString["id"].ToString());
        data.RunSql("update   Repair set  evaluate='" + Label7.Text + "' where id = " + id);
        Alert.AlertAndRedirect("操作成功！！", "student_index.aspx");
    }
 
    protected void Button1_Click(object sender, EventArgs e)
    {

        int id = int.Parse(Request.QueryString["id"].ToString());
        SqlDataReader dr;
        dr = data.GetDataReader("select * from  Repair where id=" + id);
        dr.Read();

        if (dr["reminder"].ToString() == "5")
        {
            Alert.Alertjs("你已经催了5次了，请耐心等待维修人员维修！");
        }
        else
        {
            int n = int.Parse(dr["reminder"].ToString()) + 1;
        data.ReturnSql("update repair set reminder='"+n+"' where id="+id);
        Alert.Alertjs("第"+ n +"次催单成功啦！");
        }
       
    }
}
