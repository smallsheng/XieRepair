﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class BaoXiu_student_reg : System.Web.UI.Page
{
    SqlHelper data = new SqlHelper();
    protected void Page_Load(object sender, EventArgs e)
    {



    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        if(txtname.Text.Length < 7 || TextBox1.Text.Length <7)
        {

            Alert.AlertAndRedirect("请将账户密码设置为6-8位！", "#");
        }
        else
        {
            SqlDataReader dr = data.GetDataReader("select * from Users where UserName='" + txtname.Text + "' ");
            if (dr.Read())
            {
                Label2.Text = "账号已经存在";
                return;
            }

            else
            {
                string ss = GetMD5(TextBox1.Text);

                data.RunSql("insert into Users(UserName,Sex,Class,pwd,Major,Names,identy,Tel,StuId,Photo)values('" + txtname.Text + "','" + DropDownList1.SelectedItem.Text + "','" + TextBox5.Text + "','" + ss + "','" + TextBox3.Text + "','" + XingMing.Text + "','" + DropDownList3.SelectedValue + "','" + Tel.Text + "','" + TextBox4.Text + "','" + pic.Text + "')");



                Alert.AlertAndRedirect("注册成功请登录！", "student_login.aspx");
            }
        }
       

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string res;
        upload up = new upload();
        res = up.Up(file1, "../files/");
        
      
        this.pic.Text = up.s;
        Image1.ImageUrl = "../files/" + up.s;
    
    }
    public static string GetMD5(String input)
    {
        string cl = input;
        string pwd = "";
        MD5 md5 = MD5.Create();//实例化一个md5对像
        // 加密后是一个字节类型的数组，这里要注意编码UTF8/Unicode等的选择　
        byte[] s = md5.ComputeHash(Encoding.UTF8.GetBytes(cl));
        // 通过使用循环，将字节类型的数组转换为字符串，此字符串是常规字符格式化所得
        for (int i = 0; i < s.Length; i++)
        {
            // 将得到的字符串使用十六进制类型格式。格式后的字符是小写的字母，如果使用大写（X）则格式后的字符是大写字符 

            pwd = pwd + s[i].ToString("X");

        }
        return pwd;
    }

}