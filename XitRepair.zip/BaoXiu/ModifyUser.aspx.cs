﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class Admin_ModifyTinfo : System.Web.UI.Page
{
    SqlHelper data = new SqlHelper();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            if (Session["adminid"] == null)
            {
                Alert.AlertAndRedirect("对不起您还没有登录", "student_login.aspx");
            }
            else
            {
                SqlHelper data = new SqlHelper();
                string id = Session["adminid"].ToString();
                SqlDataReader dr = data.GetDataReader("select * from Users where id=" + id);
                dr.Read();

                XingMing.Text = dr["Names"].ToString();
                BanJi.Text = dr["Class"].ToString();



                Tel.Text = dr["Tel"].ToString();
                TextBox1.Text = dr["Major"].ToString();
                Image1.ImageUrl = "../files/" + dr["Photo"].ToString();
                pic.Text = dr["Photo"].ToString();


                TextBox4.Text = dr["StuId"].ToString();
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
       
            string id = Session["adminid"].ToString();
            data.RunSql("update  Users set  Names='" + XingMing.Text + "',Class='" + BanJi.Text + "',Tel='" + Tel.Text + "',Major='" + TextBox1.Text + "',StuId='" + TextBox4.Text + "',Photo='"+pic.Text+"'  where id=" + id);
            Alert.AlertAndRedirect("修改成功", "ModifyUser.aspx");

     
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        string res;
        upload up = new upload();
        res = up.Up(file1, "../files/");
        this.Label1.Visible = true;
        this.Label1.Text = up.Resup[Convert.ToInt32(res)];
        this.pic.Text = up.s;
        Image1.ImageUrl = "../files/" + pic.Text;
    }

}
