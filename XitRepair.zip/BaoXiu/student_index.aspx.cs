﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class BaoXiu_student_index : System.Web.UI.Page
{
    SqlHelper data = new SqlHelper();
    Alert js = new Alert();
    Alert alert = new Alert();
   

    protected void Page_Load(object sender, EventArgs e)
    {  
        if (!IsPostBack)
        {
            if (Session["adminid"] == null)
            {
                Alert.AlertAndRedirect("对不起您还没有登录", "student_login.aspx");
            }
            else
            {
                string id = Session["adminid"].ToString();

                this.Label2.Text = Session["Admin"].ToString();
                SqlDataReader dr;
                dr = data.GetDataReader("select * from  Users where id=" + id);
                dr.Read();
              //  Image2.ImageUrl = "../files/" + dr["Photo"].ToString();
               // Label5.Text = dr["XingMing"].ToString();
                TextBox1.Text = Session["Admin"].ToString();
                DropDownList2.DataSource = data.GetDataReader("select * from   dbo.Dormitory ");
                DropDownList2.DataTextField = "Name";
                DropDownList2.DataValueField = "id";
                DropDownList2.DataBind();

                DropDownList1.DataSource = data.GetDataReader("select * from   dbo.BXType ");
                DropDownList1.DataTextField = "Name";
                DropDownList1.DataValueField = "id";
                DropDownList1.DataBind();

                Get_DB();
                SqlHelper dataa = new SqlHelper();
    ;
                SqlDataReader drs = dataa.GetDataReader("select * from Users where id=" + id);
                drs.Read();

                XingMing.Text = drs["Names"].ToString();
                sex.Text = drs["Sex"].ToString();        
                BanJi.Text = drs["Class"].ToString();
                tel.Text = drs["Tel"].ToString();
                zhuanye.Text = drs["Major"].ToString();
                Image3.ImageUrl = "../files/" + dr["Photo"].ToString();
                pic.Text = dr["Photo"].ToString();
               
                xuehao.Text = dr["StuId"].ToString();
            }
        }

    }

    protected void Button1_ServerClick(object sender, EventArgs e)
    {
        try
        {
 string sexs;
        string identys;
        string id = Session["adminid"].ToString();
        SqlHelper data = new SqlHelper();
        SqlDataReader drs = data.GetDataReader("select * from Users where id=" + id);
        drs.Read();
        sexs = drs["Sex"].ToString();
          identys = drs["identy"].ToString();
        data.RunSql("insert into Repair(name,[content],UserId,UserName,ReType,Tel,Dormitory,roomNum,RePhoto,Sex,UserType)values('" + txtName.Text + "','" + txtbig.Text + "','" + Session["adminid"].ToString() + "','" + TextBox1.Text + "','" + DropDownList1.SelectedItem.Text + "','" + TextBox2.Text + "'," +
            "'" + DropDownList2.SelectedItem.Text + "','"+ TextBox4.Text + "','" + pic.Text + "','" + sexs+ "','" + identys + "')");
        Alert.AlertAndRedirect("报修成功", "student_index.aspx");
        }
        catch (Exception)
        {

            Alert.AlertAndRedirect("时间过长，请重新登录", "student_login.aspx");
        }
       

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string res;
        upload up = new upload();
        res = up.Up(file1, "../files/");
        this.Label1.Visible = true;
        this.Label1.Text = up.Resup[Convert.ToInt32(res)];
        this.pic.Text = up.s;
        Image1.ImageUrl = "../files/" + pic.Text;


    }
    private void Get_DB()
    {
        try
        {


            Repeater1.DataSource = GetCodeBy(0);
            Repeater1.DataBind();
 
        }
        catch(Exception ex)
        {
            
        }

    }
    protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
     //  gv.PageIndex = e.NewPageIndex;
        Get_DB();
    }
    public DataTable GetCodeBy(int iCount)
    {
        SqlHelper date = new SqlHelper();
        string strTop = "";
        if (iCount > 1)
        {
            strTop = "top " + iCount.ToString();
        }

        string sql = "select  " + strTop + "  * from [Repair] where  UserId='" + Session["adminid"].ToString() + "' order by  AddTime desc ";
        SqlConnection con = new SqlConnection(SqlHelper.sqlconing);
        SqlCommand cmd = new SqlCommand(sql, con);

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable ds = new DataTable();
        try
        {
            con.Open();
          //  ds = new DataSet();
            da.Fill(ds);
    
        }
        catch (SqlException ex)
        {
            throw ex;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            con.Close();
        }
        return ds;
    }
}